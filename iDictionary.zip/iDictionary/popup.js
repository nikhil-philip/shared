let bgpage=chrome.extension.getBackgroundPage();
window.word=bgpage.word;
var change=document.getElementById('word');
change.textContent=window.word;

 const endpoint = `https://en.wikipedia.org/w/api.php?action=query&list=search&prop=info&inprop=url&utf8=&format=json&origin=*&srlimit=20&srsearch=${window.word}`;
  fetch(endpoint)
  .then(response => response.json())
  .then(data => {
    const results = data.query.search;
var par=document.createElement('p');
var definition=document.getElementById("div");
par.innerHTML=results[0].snippet;
definition.innerHTML="";
definition.appendChild(par);
})
    .catch(() => console.log('An error occurred'));
