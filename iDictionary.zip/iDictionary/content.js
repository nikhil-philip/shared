window.addEventListener("mouseup",mouseupped);
var json='{"Displays":"Shows something","Removes":"Removes Content"}';
var obj= JSON.parse(json);
function mouseupped(){
let txt=window.getSelection().toString();
txt=txt.trim();
console.log(txt);
if(txt.length>0)
{
let message= {
text: txt
};
chrome.runtime.sendMessage(message);
}
}