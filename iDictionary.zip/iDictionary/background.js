chrome.runtime.onMessage.addListener(receiver);
window.word="gs"
function receiver(request, sender, senderResponse)
{
window.word = request.text;
} 
